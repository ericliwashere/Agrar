const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, game: "Mass.io Online" }));

const PORT = process.env.PORT || 3000;
const WORLD = { w: 3200, h: 2400 };
const COLORS = ["#ff6b7d", "#65a9ff", "#ffc857", "#b18cff", "#54d6a0", "#ff9f5a", "#5fe0e8", "#f28ccf"];
const players = new Map();
let pellets = [];
const rand = (a,b) => a + Math.random()*(b-a);
const clamp = (n,a,b) => Math.max(a,Math.min(b,n));
const radius = mass => 10 + Math.sqrt(Math.max(1,mass))*3.2;
const speed = mass => 250 / Math.pow(Math.max(1,mass)/10, 0.22);
const distance = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);

function newPellet() {
  return { id: Math.random().toString(36).slice(2), x: rand(20,WORLD.w-20), y: rand(20,WORLD.h-20),
    r: rand(3.2,5.8), value: 1, color: COLORS[Math.floor(Math.random()*COLORS.length)] };
}
function spawn(socketId, name) {
  const mass = 10;
  return { id: socketId, name, x: rand(120,WORLD.w-120), y: rand(120,WORLD.h-120), mass,
    r: radius(mass), score: 100, color: COLORS[Math.floor(Math.random()*COLORS.length)],
    targetX: WORLD.w/2, targetY: WORLD.h/2, alive: true, lastInput: Date.now() };
}
for (let i=0;i<650;i++) pellets.push(newPellet());

io.on("connection", socket => {
  socket.emit("welcome", { world: WORLD });
  socket.on("join", rawName => {
    if (players.has(socket.id)) return;
    const name = String(rawName || "Player").replace(/[<>]/g,"").trim().slice(0,16) || "Player";
    players.set(socket.id, spawn(socket.id, name));
    socket.emit("joined", { id: socket.id });
  });
  socket.on("aim", pos => {
    const p = players.get(socket.id);
    if (!p || !p.alive || !pos) return;
    const x = Number(pos.x), y = Number(pos.y);
    if (Number.isFinite(x) && Number.isFinite(y)) {
      p.targetX = clamp(x,0,WORLD.w);
      p.targetY = clamp(y,0,WORLD.h);
      p.lastInput = Date.now();
    }
  });
  socket.on("respawn", rawName => {
    if (players.has(socket.id)) return;
    const name = String(rawName || "Player").replace(/[<>]/g,"").trim().slice(0,16) || "Player";
    players.set(socket.id, spawn(socket.id, name));
  });
  socket.on("disconnect", () => players.delete(socket.id));
});

function canEat(big, small) {
  if (!big.alive || !small.alive || big.id === small.id || big.mass < small.mass*3) return false;
  const overlap = clamp((big.r + small.r - distance(big,small))/(2*small.r),0,1);
  return overlap >= 0.5;
}
function eat(eater, prey) {
  eater.mass += Math.max(2, prey.mass*0.72);
  eater.r = radius(eater.mass);
  eater.score = Math.round(eater.mass*10);
  prey.alive = false;
  io.to(prey.id).emit("eaten", { by: eater.name, score: prey.score });
  players.delete(prey.id);
}
function tick() {
  const dt = 0.05;
  const active = [...players.values()].filter(p => p.alive);
  for (const p of active) {
    const dx = p.targetX-p.x, dy=p.targetY-p.y, d=Math.hypot(dx,dy), s=speed(p.mass);
    if (d>3) { p.x += dx/d*Math.min(d,s*dt); p.y += dy/d*Math.min(d,s*dt); }
    p.x=clamp(p.x,p.r,WORLD.w-p.r); p.y=clamp(p.y,p.r,WORLD.h-p.r); p.r=radius(p.mass);
    p.score=Math.round(p.mass*10);
  }
  // Pellet pickup is authoritative on the server.
  for (const p of active) {
    for (let i=pellets.length-1;i>=0;i--) {
      const food=pellets[i];
      if (Math.hypot(p.x-food.x,p.y-food.y) < p.r+food.r) {
        p.mass += 0.14; p.r=radius(p.mass); p.score=Math.round(p.mass*10);
        pellets.splice(i,1); pellets.push(newPellet());
      }
    }
  }
  // Largest players get first chance to eat.
  const sorted=[...players.values()].filter(p=>p.alive).sort((a,b)=>b.mass-a.mass);
  for (let i=0;i<sorted.length;i++) {
    const eater=sorted[i];
    if (!players.has(eater.id)) continue;
    for (let j=i+1;j<sorted.length;j++) {
      const prey=sorted[j];
      if (!players.has(prey.id)) continue;
      if (canEat(eater,prey)) eat(eater,prey);
      else if (canEat(prey,eater)) eat(prey,eater);
    }
  }
  const current=[...players.values()].map(p=>({
    id:p.id,name:p.name,x:p.x,y:p.y,mass:p.mass,r:p.r,score:p.score,color:p.color
  }));
  const board=current.slice().sort((a,b)=>b.score-a.score).slice(0,10).map(p=>({id:p.id,name:p.name,score:p.score,color:p.color}));
  io.emit("state", { world: WORLD, players: current, pellets, leaderboard: board });
}
setInterval(tick,50);
server.listen(PORT, "0.0.0.0", () => console.log(`Mass.io Online listening on ${PORT}`));
