# Mass.io Online

A free-to-play browser arena prototype with real-time multiplayer using Node.js, Express, and Socket.IO.

## Features
- Players choose a display name.
- Everyone connects to one shared arena.
- Server-authoritative movement, pellet collection, mass, score, and eating.
- Bigger players move more slowly.
- Eating requires at least 3x mass and 50% overlap of the smaller player's radius.
- Leaderboard and mobile touch controls.

## Deploy it publicly for free

### Easiest path: Render
1. Create a GitHub account if you don't already have one.
2. Create a new GitHub repository and upload the files in this folder.
3. Sign in to Render and choose **New + → Blueprint**.
4. Connect your repository. Render will detect `render.yaml`.
5. Deploy the service and wait for it to finish.
6. Open the public `https://...onrender.com` URL. Share that URL with friends.

The free plan's availability and sleep behavior can change. A free instance may sleep when idle, so the first visit after inactivity can take a little while to wake up. Check the host's current free-tier terms before publishing.

### Run it locally
Install Node.js 18 or newer, then from this folder run:

```bash
npm install
npm start
```

Open http://localhost:3000.

## Notes
- This is a prototype, not a hardened production game. It has no accounts, chat, moderation system, or persistent stats.
- Names are display names only; players can reuse each other's names.
- Public deployment means strangers may join. Add rate limits, moderation, and anti-cheat protections before a larger launch.
- The game is inspired by arena-growth games; it does not use their branding or assets.
